<?php
$db = new PDO('sqlite:/home/user/winfeen/api/storage/app.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$want = ['categories', 'specialties', 'services', 'service_requests', 'governorates', 'regions'];
foreach ($db->query("SELECT name, sql FROM sqlite_master WHERE type='table'") as $r) {
    if (in_array($r['name'], $want, true)) {
        echo "── {$r['name']} ──\n" . $r['sql'] . "\n\n";
    }
}

echo "══ إحصاءات ══\n";
echo "  الأقسام: " . $db->query("SELECT COUNT(*) FROM categories")->fetchColumn() . "\n";
echo "  الاختصاصات: " . $db->query("SELECT COUNT(*) FROM specialties")->fetchColumn() . "\n";
echo "  الخدمات: " . $db->query("SELECT COUNT(*) FROM services")->fetchColumn() . "\n";

echo "\n══ الاختصاصات الحالية ══\n";
foreach ($db->query("SELECT * FROM specialties ORDER BY id") as $r) {
    echo "  #{$r['id']} {$r['name']} | slug={$r['slug']} | icon=" . ($r['icon'] ?? '—') . "\n";
}

echo "\n══ الأقسام ══\n";
foreach ($db->query("SELECT id, slug, name, icon, features FROM categories ORDER BY id") as $r) {
    echo "  #{$r['id']} {$r['slug']} «{$r['name']}» icon={$r['icon']}\n";
    echo "      features: " . ($r['features'] ?: '—') . "\n";
}
