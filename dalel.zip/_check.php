<?php
$db = new PDO('sqlite:/home/user/winfeen/api/storage/app.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "══ خدمات الأطباء ══\n";
$n = $db->query("SELECT COUNT(*) FROM services WHERE category_id = 38")->fetchColumn();
echo "  العدد: $n\n";
$withSp = $db->query("SELECT COUNT(*) FROM services WHERE category_id=38 AND specialty_id IS NOT NULL")->fetchColumn();
echo "  منها باختصاص (specialty_id): $withSp\n";

echo "\n══ عيّنة من أسماء الأطباء ══\n";
foreach ($db->query("SELECT name, meta FROM services WHERE category_id=38 LIMIT 8") as $r) {
    echo "  • {$r['name']}\n      meta: " . ($r['meta'] ?: '{}') . "\n";
}

echo "\n══ الحقول والخيارات ══\n";
foreach ($db->query("SELECT f.id, f.field_key, f.label, f.type, c.name cat,
                     (SELECT COUNT(*) FROM category_field_options o WHERE o.field_id=f.id) opts
                     FROM category_fields f JOIN categories c ON c.id=f.category_id") as $r) {
    echo "  #{$r['id']} «{$r['label']}» ({$r['field_key']}) نوع={$r['type']} قسم={$r['cat']} خيارات={$r['opts']}\n";
}

echo "\n══ أول ٥ خيارات ══\n";
foreach ($db->query("SELECT label, value, icon FROM category_field_options ORDER BY sort_order LIMIT 5") as $r) {
    echo "  {$r['icon']}  «{$r['label']}» = {$r['value']}\n";
}
