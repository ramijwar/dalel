<?php
$base = 'http://127.0.0.1:8013/dalel/api';

function call(string $method, string $path, ?array $body = null, ?string $token = null): array {
    $ch = curl_init($GLOBALS['base'] . $path);
    $h  = ['Content-Type: application/json', 'Accept: application/json'];
    if ($token) $h[] = "Authorization: Bearer $token";
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => $method,
        CURLOPT_HTTPHEADER     => $h,
        CURLOPT_TIMEOUT        => 20,
    ]);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
    $raw = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['code' => $code, 'data' => json_decode((string) $raw, true) ?: $raw];
}

function show(string $label, array $r) {
    $ok = ($r['code'] >= 200 && $r['code'] < 300);
    echo ($ok ? "  ✓ " : "  ✗ ") . $label . " [HTTP {$r['code']}]\n";
    if (!$ok) echo "      " . json_encode($r['data'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    return $r['data'];
}

// ─── دخول أدمن ───
$db = new PDO('sqlite:/home/user/winfeen/api/storage/app.sqlite');
$old = $db->query("SELECT password_hash FROM users WHERE id=33")->fetchColumn();
file_put_contents('/tmp/oldhash.txt', (string) $old);
$db->prepare("UPDATE users SET password_hash=? WHERE id=33")->execute([password_hash('Test123456', PASSWORD_DEFAULT)]);

$tok = call('POST', '/auth/login', ['phone' => '0991000001', 'password' => 'Test123456'])['data']['token'] ?? '';
echo "التوكن: " . substr((string) $tok, 0, 22) . "…\n\n";

echo "══ ١) قراءة حقول الأطباء ══\n";
$d = show('GET /admin/category-fields?category_id=38', call('GET', '/admin/category-fields?category_id=38', null, $tok));
$specFieldId = (int) ($d['items'][0]['id'] ?? 0);
echo "      معرّف حقل الاختصاص: $specFieldId · خيارات: " . count($d['items'][0]['options'] ?? []) . "\n\n";

echo "══ ٢) إضافة خيار جديد للاختصاصات ══\n";
$d = show('POST option «طب رياضي»', call('POST', "/admin/category-fields/$specFieldId/options",
    ['label' => 'طب رياضي', 'value' => 'sports-med', 'icon' => 'dumbbell'], $tok));
$newOptId = (int) ($d['id'] ?? 0);
echo "      معرّف الخيار الجديد: $newOptId\n\n";

echo "══ ٣) التحقق: ٢١ خياراً الآن ══\n";
$d = show('GET fields', call('GET', '/admin/category-fields?category_id=38', null, $tok));
echo "      عدد الخيارات: " . count($d['items'][0]['options'] ?? []) . "\n\n";

echo "══ ٤) حقل جديد لقسم الصيدليات (نص) ══\n";
$d = show('POST text field «اسم الصيدلاني»', call('POST', '/admin/category-fields', [
    'category_id' => 37, 'key' => 'pharmacist_name', 'label' => 'اسم الصيدلاني',
    'type' => 'text', 'required' => false, 'placeholder' => 'مثال: أحمد محمد',
], $tok));
$phFieldId = (int) ($d['id'] ?? 0);
echo "      معرّف الحقل الجديد: $phFieldId\n\n";

echo "══ ٥) حقل قائمة جديد للكازيات (نوع الوقود) ══\n";
$d = show('POST select field «نوع الوقود» مع خيارات', call('POST', '/admin/category-fields', [
    'category_id' => 39, 'key' => 'fuel_type', 'label' => 'نوع الوقود',
    'type' => 'select', 'required' => true, 'placeholder' => 'اختر نوع الوقود…',
    'options' => [
        ['label' => 'بنزين 90', 'value' => 'gas90', 'icon' => 'fuel'],
        ['label' => 'بنزين 95', 'value' => 'gas95', 'icon' => 'fuel'],
        ['label' => 'مازوت', 'value' => 'diesel', 'icon' => 'truck'],
    ],
], $tok));
$fuelFieldId = (int) ($d['id'] ?? 0);
echo "      معرّف الحقل: $fuelFieldId\n\n";

echo "══ ٦) التحقق من الإلزام: خدمة كازية بدون نوع وقود ══\n";
$svc = call('GET', '/admin/services?limit=1&category_id=39', null, $tok)['data']['items'][0] ?? null;
if (!$svc) { echo "  ⚠ لم تُعثر على خدمة للكازيات — جرّب القسم 37\n";
    $svc = call('GET', '/admin/services?limit=1&category_id=39', null, $tok)['data']['items'][0] ?? null; }
echo "      الخدمة المختارة: " . ($svc['name'] ?? '—') . " #" . ($svc['id'] ?? '—') . "\n";
if ($svc) {
    $r = call('PUT', '/admin/services/' . $svc['id'], [
        'category_id' => 39, 'name' => $svc['name'], 'governorate_id' => 1,
        'fields' => [],   // حقل إلزامي مفقود
    ], $tok);
    echo ($r['code'] === 422 ? "  ✓ " : "  ✗ ") . "رُفض بحقل إلزامي ناقص [HTTP {$r['code']}]\n";
    echo "      الرسالة: " . ($r['data']['message'] ?? '—') . "\n\n";
}

echo "══ ٧) تمرير قيمة صحيحة ══\n";
if ($svc) {
    $r = call('PUT', '/admin/services/' . $svc['id'], [
        'category_id' => 39, 'name' => $svc['name'], 'governorate_id' => 1,
        'fields' => ['fuel_type' => 'gas95'],
    ], $tok);
    echo (($r['code'] >= 200 && $r['code'] < 300) ? "  ✓ " : "  ✗ ") . "حُفظت القيمة [HTTP {$r['code']}]\n";
    if ($r['code'] >= 400) echo "      " . json_encode($r['data'], JSON_UNESCAPED_UNICODE) . "\n";

    // تحقق من الحلّ
    $det = call('GET', '/services/' . $svc['id'])['data']['service'] ?? [];
    echo "      الحقول المحلولة:\n";
    foreach (($det['fields'] ?? []) as $f) echo "        • {$f['label']}: {$f['display']}\n";
    echo "\n";
}

echo "══ ٨) رفض قيمة خيار غير موجودة ══\n";
if ($svc) {
    $r = call('PUT', '/admin/services/' . $svc['id'], [
        'category_id' => 39, 'name' => $svc['name'], 'governorate_id' => 1,
        'fields' => ['fuel_type' => 'غير-موجود'],
    ], $tok);
    echo ($r['code'] === 422 ? "  ✓ " : "  ✗ ") . "رُفضت القيمة غير الصالحة [HTTP {$r['code']}]\n";
    echo "      الرسالة: " . ($r['data']['message'] ?? '—') . "\n\n";
}

echo "══ ٩) تنظيف بيانات الاختبار ══\n";
show('حذف حقل الوقود', call('DELETE', "/admin/category-fields/$fuelFieldId", null, $tok));
show('حذف حقل الصيدلاني', call('DELETE', "/admin/category-fields/$phFieldId", null, $tok));
show('حذف خيار طب رياضي', call('DELETE', "/admin/category-fields/$specFieldId/options/$newOptId", null, $tok));

// أعد كلمة المرور
$db->prepare("UPDATE users SET password_hash=? WHERE id=33")->execute([file_get_contents('/tmp/oldhash.txt')]);
@unlink('/tmp/oldhash.txt');
echo "\n✓ أُعيدت كلمة المرور ونُظّفت بيانات الاختبار\n";
