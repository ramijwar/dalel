<?php
$db = new PDO('sqlite:/home/user/winfeen/api/storage/app.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// هل specialty_id يطابق الاسم المخزّن في meta.specialty؟
$ok = 0; $bad = 0; $samples = [];
foreach ($db->query("SELECT s.id, s.name, s.specialty_id, s.meta,
                            sp.name AS sp_name
                     FROM services s
                     LEFT JOIN specialties sp ON sp.id = s.specialty_id
                     WHERE s.category_id = 38") as $r) {
    $meta = json_decode((string) ($r['meta'] ?: '{}'), true) ?: [];
    $mSp = (string) ($meta['specialty'] ?? '');
    if ($mSp === (string) ($r['sp_name'] ?? '')) {
        $ok++;
    } else {
        $bad++;
        if (count($samples) < 5) {
            $samples[] = "  #{$r['id']} {$r['name']}\n      meta.specialty = «{$mSp}»\n      specialty_id={$r['specialty_id']} → «{$r['sp_name']}»";
        }
    }
}
echo "══ تطابق specialty_id مع meta.specialty ══\n";
echo "  مطابق: $ok\n";
echo "  مختلف: $bad\n";
foreach ($samples as $s) echo $s . "\n";

// كم خدمة لها meta.specialty كاسم وليس كرقم؟
$named = 0; $numeric = 0;
foreach ($db->query("SELECT meta FROM services WHERE category_id = 38") as $r) {
    $meta = json_decode((string) ($r['meta'] ?: '{}'), true) ?: [];
    $v = (string) ($meta['specialty'] ?? '');
    if ($v === '') continue;
    if (ctype_digit($v)) $numeric++; else $named++;
}
echo "\n══ صيغة القيم الحالية ══\n";
echo "  كنص (اسم): $named\n";
echo "  كرقم (id): $numeric\n";
