<?php
$db = new PDO('sqlite:/home/user/winfeen/api/storage/app.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

echo "══ كل الحقول ══\n";
foreach ($db->query("SELECT f.id, f.category_id, f.field_key, f.label, f.type, f.is_active, c.name cat
                     FROM category_fields f LEFT JOIN categories c ON c.id=f.category_id") as $r) {
    echo "  #{$r['id']} «{$r['label']}» key={$r['field_key']} type={$r['type']} active={$r['is_active']} قسم={$r['cat']} ({$r['category_id']})\n";
}

echo "\n══ عدد الخيارات لكل حقل ══\n";
foreach ($db->query("SELECT field_id, COUNT(*) c FROM category_field_options GROUP BY field_id") as $r) {
    echo "  حقل #{$r['field_id']}: {$r['c']} خيار\n";
}

echo "\n══ فحص مباشر لـ category_fields_list(38) ══\n";
require '/home/user/winfeen/api/includes/db.php';
require '/home/user/winfeen/api/includes/helpers.php';
require '/home/user/winfeen/api/includes/fields.php';
$f = category_fields_list(38);
echo "  عدد الحقول المرجعة: " . count($f) . "\n";
foreach ($f as $x) echo "    «{$x['label']}» خيارات=" . count($x['options']) . "\n";
