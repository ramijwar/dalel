# وين في؟ — دليل الخدمات اليومية

## هل يحتاج React بناء؟
**لا!** الواجهة مبنية مسبقاً (`client/dist/`) — ملفات HTML/CSS/JS جاهزة.
**لا تحتاج Node.js أو npm على الاستضافة.**
所需要 فقط: **PHP 7.4+** مع إضافة **pdo_sqlite**.

---

## التثبيت على الاستضافة

### 1. رفع الملفات
ارفع محتويات هذا الملف المضغوط إلى مجلد الموقع (public_html أو www):

```
📁 /
├── router.php          ← نقطة الدخول (يربط الواجهة + API)
├── api/
│   ├── index.php       ← الـ API الرئيسي
│   ├── seed.php        ← تزويد البيانات (اختياري)
│   ├── includes/
│   │   ├── db.php      ← اتصال قاعدة البيانات + المخطط
│   │   ├── auth.php    ← المصادقة والصلاحيات
│   │   ├── helpers.php ← أدوات مساعدة
│   │   └── token.php   ← رموز JWT
│   └── storage/        ← ⚠️ يجب أن يكون قابلاً للكتابة (chmod 755)
│       └── app.sqlite  ← قاعدة البيانات (تُنشأ تلقائياً)
└── client/
    └── dist/           ← الواجهة المبنية جاهزة
        ├── index.html
        └── assets/
            ├── index-*.js
            └── index-*.css
```

### 2. إعداد Apache (.htaccess)
أنشئ ملف `.htaccess` في جذر الموقع:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ router.php [L,QSA]
```

### 3. إعداد Nginx
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /path/to/uploaded/files;
    index index.html;

    location / {
        try_files $uri $uri/ /router.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

### 4. إنشاء قاعدة البيانات
إذا لم تكن `api/storage/app.sqlite` موجودة، شغّل مرة واحدة:
```bash
php api/seed.php
```
هذا يُنشئ 516 خدمة حقيقية (240 صيدلية + 150 طبيب + 90 كازية + 18 خط نقل + 18 بازار).

### 5. صلاحيات المجلدات
```bash
chmod 755 api/storage/
chmod 644 api/storage/app.sqlite
```

---

## حسابات الدخول الافتراضية

| الدور | الهاتف | كلمة المرور |
|-------|--------|-------------|
| مدير النظام | 0991000001 | admin123 |
| صيدلاني | 0991000002 | user1234 |
| طبيبة | 0991000003 | user1234 |
| مستخدم عادي | 0991000004 | user1234 |

---

## المتطلبات
- PHP 7.4+ (مُختبَر على 8.4)
- PDO + SQLite3
- mbstring (اختياري — يعمل بدونها)
- GD (اختياري — لتقليص الصور الشخصية)

## تحديث الواجهة (إن رغبت بالتطوير)
```bash
cd client
npm install
npm run build    # يُنشئ الملفات في client/dist/
```
