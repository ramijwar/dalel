# دليل الدير — دليل الخدمات اليومية

## هل يحتاج React بناء؟
**لا!** الواجهة مبنية مسبقاً (`assets/`) — ملفات HTML/CSS/JS جاهزة.
**لا تحتاج Node.js أو npm على الاستضافة.**
تحتاج فقط: **PHP 7.4+** مع إضافة **pdo_sqlite**.

---

## 🔴 أمان — اقرأ هذا أولاً

مجلد `api/storage/` يحتوي على **قاعدة البيانات** و**مفتاح توقيع الجلسات**.
إن كان هذا المجلد متاحاً عبر الويب فالثغرة حرجة:

| ما يُسرَّب | النتيجة |
|---|---|
| `secret.key` | تزوير رمز دخول بصلاحيات **مدير** — دون أي كلمة مرور |
| `app.sqlite` | كل أرقام الهاتف وهاشات كلمات المرور وبيانات المستخدمين |
| `seed.php` · `install.php` | **محو قاعدة البيانات بالكامل** بطلب واحد |

### الطبقات الثلاث للحماية (مطبَّقة كلها)

**① `api/storage/.htaccess`** — يمنع كل وصول مباشر على Apache/LiteSpeed.

**② `.htaccess` الجذري** — قواعد منع في الأعلى تسبق قاعدة خدمة الملفات:
```apache
RewriteRule ^api/storage(/.*)?$ - [F,L]
RewriteRule ^api/(install|seed|migrate_fields)\.php$ - [F,L]
RewriteRule \.(sqlite|sqlite3|db|key|bak|backup|sql)$ - [F,L]
```

**③ حماية داخل PHP** (`api/includes/maintenance.php`) — تعمل على أي خادم:
سكربتات الصيانة ترفض العمل عبر الويب إلا برمز مدير صالح. من الطرفية (CLI) تعمل دائماً.

### ⚠️ على Nginx — أضف هذا يدوياً

Nginx **لا يقرأ `.htaccess`**، فالحماية ① و ② لا تنطبق. أضف داخل `server { }`:

```nginx
# منع الوصول إلى قاعدة البيانات ومفتاح الجلسات وسكربتات الصيانة
location ~ ^/api/storage/ { deny all; return 404; }
location ~ ^/api/(install|seed|migrate_fields|set_password)\.php$ { deny all; return 404; }
location ~* \.(sqlite|sqlite3|db|key|bak|backup|sql)$ { deny all; return 404; }
```

> الحماية ③ تعمل على Nginx أيضاً — فهي في PHP نفسه.

### ✅ كيف تتأكد أن موقعك آمن؟

افتح صفحة الفحص وأضف مسار تطبيقك:
```
https://yourdomain.com/dalel/check.html
```
تفحص الصفحة الآن **سرية قاعدة البيانات ومفتاح الجلسات** وتعرض تحذيراً أحمر إن كانا مكشوفين، مع الحل.

### 🔑 إن سُرِّب المفتاح (أو شككت)

```bash
# ١) بدّل مفتاح الجلسات (يُسجّل خروج الجميع — هذا هو المقصود)
mv api/storage/secret.key api/storage/secret.key.old
#    سيُولَّد مفتاح جديد تلقائياً عند أول طلب

# ٢) غيّر كلمة مرور المدير
php api/set_password.php <رقم_الهاتف>
```

---

## التثبيت على الاستضافة

### 1. رفع الملفات
ارفع محتويات هذا المجلد إلى مجلد الموقع (public_html أو www):

```
📁 /
├── router.php          ← نقطة الدخول (تربط الواجهة + API)
├── .htaccess           ← ⚠️ ضروري — لا تنسَه (ملف مخفي)
├── index.html + assets/  ← الواجهة المبنية
├── check.html          ← صفحة فحص الصحة والأمان
├── api/
│   ├── api.php          ← الـ API الرئيسي
│   ├── install.php      ← مُثبّت قاعدة بيانات جديدة
│   ├── seed.php         ← تزويد ببيانات تجريبية
│   ├── set_password.php ← تعيين كلمة مرور (من الطرفية فقط)
│   ├── includes/
│   │   ├── db.php           ← اتصال قاعدة البيانات + المخطط
│   │   ├── auth.php         ← المصادقة والصلاحيات
│   │   ├── helpers.php      ← أدوات مساعدة
│   │   ├── token.php        ← رموز الجلسات (HMAC-SHA256)
│   │   ├── fields.php       ← محرّك الحقول الديناميكية
│   │   └── maintenance.php  ← 🔒 حماية سكربتات الصيانة
│   └── storage/         ← ⚠️ يجب أن يكون قابلاً للكتابة
│       ├── .htaccess    ← 🔒 يمنع الوصول المباشر — لا تحذفه
│       ├── app.sqlite   ← قاعدة البيانات
│       └── secret.key   ← مفتاح توقيع الجلسات
└── README.md
```

> 📎 **خارج هذه الحزمة:** مجلد `_data-archive/` في المستودع يحتوي قواعد بيانات **مهجورة**
> (منها نسخة قديمة بـ٥٢٣ خدمة). لا تُرفع إلى الاستضافة ولا تُدمج — راجع `_data-archive/README.md`.

### 2. إعداد Apache (.htaccess)
الملف مرفق جاهز في نفس المجلد. تأكد من رفعه (فعّل «إظهار الملفات المخفية» في برنامج FTP).

### 3. إعداد Nginx
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    root /path/to/uploaded/files;
    index index.html;

    # 🔒 أولاً: حماية مجلد التخزين والسكربتات الحساسة
    location ~ ^/api/storage/ { deny all; return 404; }
    location ~ ^/api/(install|seed|migrate_fields|set_password)\.php$ { deny all; return 404; }
    location ~* \.(sqlite|sqlite3|db|key|bak|backup|sql)$ { deny all; return 404; }

    location / {
        try_files $uri $uri/ /router.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

### 4. صلاحيات المجلدات
```bash
chmod 755 api/storage/
chmod 644 api/storage/app.sqlite
chmod 600 api/storage/secret.key
```

---

## قاعدة البيانات المعتمدة

**لا توجد الآن إلا نسخة واحدة معتمدة** — القديمة مهجورة ونُقلت إلى `_data-archive/deprecated/`.

| | ✅ المعتمدة<br>`api/storage/app.sqlite` |
|---|---|
| اسم الموقع | دليل الدير |
| المحافظات | حلب · **ديرالزور** |
| المناطق | **١٥٨** |
| الخدمات | ٣٩٢ |
| الحقول الديناميكية | **٥ حقول · ٣٤ خياراً** |

> ⛔ **لا تدمج البيانات القديمة.** كانت تحتوي ٥٢٣ خدمة، لكنها بيانات قديمة جرى تعديلها —
> والعدد الأكبر لا يعني أنها الأصحّ. راجع `_data-archive/README.md` للتفاصيل.

### 📌 حالة البيانات الحالية — تفصيل

```
المحافظات
  # 1  حلب        ← ٧٢ منطقة (مدن)                            ·  ٣٩٢ خدمة
  #10  ديرالزور   ← ٨٦ منطقة (٢٥ مدينة + ٥٩ ريفية + ٢ قرية)   ·  ٠ خدمة
```

| القسم | الخدمات |
|---|---|
| صيدليات بشرية | ٢٤٢ (كلها في حلب) |
| عيادات أطباء | ١٥٠ (كلها في حلب) |
| كازيات | ٠ |
| سرفيس واسعافية | ٠ |
| المخابر | ٠ |

**القراءة:** هيكل ديرالزور جاهز لكن بلا خدمات بعد، والأقسام الثلاثة الأخيرة فارغة في كل المحافظات.
هذا هو الواقع الحالي للبيانات — لا خلل في التطبيق.

`settings.tagline` ما زال يقول «…في مدينة حلب…» و`settings.city` فارغ — يُضبطان من **لوحة الإدارة ← الإعدادات**.

---

## إنشاء قاعدة بيانات جديدة

```bash
php api/install.php            # من الطرفية
# أو من المتصفح (تثبيت أول فقط — بلا مدير بعد):
# https://yourdomain.com/dalel/api/install.php
```
> بعد وجود حساب مدير لم يعد المتصفح كافياً — يلزم رمز مدير صالح. هذا مقصود.

---

## حسابات الدخول

| الدور | الهاتف | ملاحظة |
|---|---|---|
| مدير النظام | — | كلمة المرور غير معروفة في النسخة المعتمدة |

**لعرض الحسابات أو تعيين كلمة مرور جديدة:**
```bash
php api/set_password.php --list
php api/set_password.php 0936651837            # يولّد كلمة قوية تلقائياً
php api/set_password.php 0936651837 "MyPass123"
```
> 🔒 الأداة ترفض العمل عبر المتصفح نهائياً — من الطرفية فقط.

---

## المتطلبات
- PHP 7.4+ (مُختبَر على 8.3 و 8.4)
- PDO + SQLite3
- mbstring (اختياري — يعمل بدونها)
- GD (اختياري — لتقليص الصور الشخصية)

## تحديث الواجهة (إن رغبت بالتطوير)
```bash
cd client
npm install
npm run build
cp -r dist/* ../      # ينسخ index.html و assets/ إلى جذر النشر
```

---

## فحص التثبيت

```
https://yourdomain.com/dalel/check.html
```
تفحص: مسار التطبيق · `/api/health` · `/api/meta` · `/api/home` · تسجيل الدخول
· **سرية قاعدة البيانات** · **سرية مفتاح الجلسات**.
